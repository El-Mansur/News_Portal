##  Models
----------------
-   Category
    -   Title
    -   Image
-   News
    -   Category
    -   Title
    -   Image
    -   Detail
-   Comments
    -   News
    -   Name
    -   Email
    -   Comments
    -   Status

##  Templates
---------------------
-   views.py
-   urls.py
-   project/urls.py
-   templates
    -   base.html
    -   index.html
    -   category.html
    -   detail.html